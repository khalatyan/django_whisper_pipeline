"""
Seamless Polymorphic Inheritance for Django Models

Copyright:
This code and affiliated files are (C) by Bert Constantin and individual contributors.
Please see LICENSE and AUTHORS for more information.
"""

VERSION = "4.1.0"

# version synonym for backwards compatibility
__version__ = VERSION
